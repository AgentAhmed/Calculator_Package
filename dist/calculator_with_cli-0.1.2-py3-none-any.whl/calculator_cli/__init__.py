from .calculator import add , subtract,divide,modulus,multiply,power,square_root

__version__ = "0.1.0"